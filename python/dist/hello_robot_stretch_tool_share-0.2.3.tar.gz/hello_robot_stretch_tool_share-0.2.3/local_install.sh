#! /bin/bash
cp -rf stretch_tool_share/* $HOME/.local/lib/python2.7/site-packages/stretch_tool_share
echo "Copied python to $HOME/.local/lib/python2.7/site-packages/stretch_tool_share/"