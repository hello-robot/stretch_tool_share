from stretch_body.end_of_arm import EndOfArm

class ToolDryEraseHolderV1(EndOfArm):
    def __init__(self, name='tool_dry_erase_holder_v1'):
        EndOfArm.__init__(self, name)
